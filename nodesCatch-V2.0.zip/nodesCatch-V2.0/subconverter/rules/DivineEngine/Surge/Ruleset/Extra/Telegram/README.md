## 说明

Telegram 的主分流文件 Telegram.list 已收录于 Global.list 中，如无确切目的不需要额外添加。

Telegram.list 用于专门想对 Telegram 服务进行指定服务器节点，以达到加速目的所用。

而至于其他三个分流文件：
- TelegramNL.list
- TelegramSG.list
- TelegramUS.list

则为更具体所用，是针对 Telegram 目前几大数据中心的更具体的分流，主要是给使用 Telegram 大文件传输，指定更为具体区域的服务器节点以达到加速目的所用。